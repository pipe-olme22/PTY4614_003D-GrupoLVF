import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getRegistros } from "../api";

export default function PatientView() {
  const { id } = useParams();
  const [registros, setRegistros] = useState([]);

  useEffect(() => {
    getRegistros(id).then(setRegistros);
  }, [id]);

  return (
    <div className="patient-view">
      <h2>Ficha del Residente {id}</h2>
      {registros.map((r, i) => (
        <div key={i} className="registro">
          <p>Temperatura: {r.signos_vitales.temperatura} °C</p>
          <p>Presión: {r.signos_vitales.presion_sistolica}/{r.signos_vitales.presion_diastolica}</p>
          <p>Frecuencia: {r.signos_vitales.frecuencia_cardiaca} bpm</p>
          <p>Saturación: {r.signos_vitales.saturacion_oxigeno}%</p>
          <p>Observaciones: {r.observaciones}</p>
        </div>
      ))}
    </div>
  );
}
