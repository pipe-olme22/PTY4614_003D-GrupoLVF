import React, { useEffect, useState } from "react";
import { getResidentes, getRegistros } from "../api";
import TakeVitalsForm from "./TakeVitalsForm";
import { Chart } from "chart.js";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const [role, setRole] = useState(localStorage.getItem("userRole"));
  const [residentes, setResidentes] = useState([]);
  const [selected, setSelected] = useState("");
  const [registros, setRegistros] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    getResidentes().then(setResidentes);
  }, []);

  useEffect(() => {
    if (selected) getRegistros(selected).then(setRegistros);
  }, [selected]);

  const logout = () => {
    localStorage.clear();
    navigate("/");
  };

  return (
    <div className="dashboard-container">
      <h2>Bienvenido ({role})</h2>
      <button onClick={logout}>Cerrar sesión</button>

      {role === "TENS" && <TakeVitalsForm />}

      {(role === "Jefe" || role === "Familiar" || role === "Cuidador") && (
        <>
          <h3>Reportes de Residentes</h3>
          <select onChange={(e) => setSelected(e.target.value)}>
            <option value="">Seleccione un residente</option>
            {residentes.map((r) => (
              <option key={r.id_residente} value={r.id_residente}>
                {r.nombre_completo}
              </option>
            ))}
          </select>
          <canvas id="temperaturaChart"></canvas>
        </>
      )}
    </div>
  );
}
