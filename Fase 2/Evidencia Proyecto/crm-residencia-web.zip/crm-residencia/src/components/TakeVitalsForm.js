import React, { useState } from "react";
import { enviarRegistro } from "../api";

export default function TakeVitalsForm() {
  const [form, setForm] = useState({
    id_residente: "",
    tens_responsable: "",
    temperatura: "",
    presion_sistolica: "",
    presion_diastolica: "",
    frecuencia_cardiaca: "",
    saturacion_oxigeno: "",
    observaciones: ""
  });

  const handleChange = (e) =>
    setForm({ ...form, [e.target.id]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      id_residente: form.id_residente,
      tens_responsable: form.tens_responsable,
      signos_vitales: {
        temperatura: parseFloat(form.temperatura),
        presion_sistolica: parseInt(form.presion_sistolica),
        presion_diastolica: parseInt(form.presion_diastolica),
        frecuencia_cardiaca: parseInt(form.frecuencia_cardiaca),
        saturacion_oxigeno: parseInt(form.saturacion_oxigeno)
      },
      observaciones: form.observaciones
    };
    await enviarRegistro(payload);
    alert("Registro enviado correctamente");
  };

  return (
    <form className="form-tens" onSubmit={handleSubmit}>
      <h3>Registro TENS</h3>
      {Object.keys(form).map((key) =>
        key !== "observaciones" ? (
          <input
            key={key}
            id={key}
            value={form[key]}
            onChange={handleChange}
            placeholder={key.replace("_", " ")}
          />
        ) : (
          <textarea
            key={key}
            id={key}
            value={form[key]}
            onChange={handleChange}
            placeholder="Observaciones"
          />
        )
      )}
      <button type="submit">Enviar</button>
    </form>
  );
}
