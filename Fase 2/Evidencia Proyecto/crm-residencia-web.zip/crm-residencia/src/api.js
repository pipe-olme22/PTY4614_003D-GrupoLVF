const BASE_URL = process.env.REACT_APP_N8N_BASE;

export async function login(email, password) {
  const res = await fetch(`${BASE_URL}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });
  return await res.json();
}

export async function getResidentes() {
  const res = await fetch(`${BASE_URL}/get_residentes`);
  return await res.json();
}

export async function getRegistros(id) {
  const res = await fetch(`${BASE_URL}/get_registros?id_residente=${id}`);
  return await res.json();
}

export async function enviarRegistro(data) {
  const res = await fetch(`${BASE_URL}/control_tens`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
  return await res.json();
}
